package com.lms.controller;

import java.io.IOException;


import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.lms.helper.FactoryManagerDB;
import com.lms.model.ManagerLeaveModel;
import com.lms.model.ManagerRetrieveList;
import com.lms.service.ManagerService;

/**
 * Servlet implementation class ManagerController
 */
@WebServlet("/manager")
public class ManagerController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ManagerService managerService=null;
    /**
     * Default constructor. 
     */
    public ManagerController() {
        // TODO Auto-generated constructor stub
    	super();
    }

    @Override
    public void init(ServletConfig config) throws ServletException {
    	super.init(config);
    	this.managerService=FactoryManagerDB.listLeavesManagerService();
    	
    }
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String action=request.getParameter("action");
		if(action.contentEquals("list")) {
			List<ManagerRetrieveList> managerRetrieveList=managerService.retrieveListOfLeaves();
			request.setAttribute("managerRetrieveList", managerRetrieveList);
			
			if(!managerRetrieveList.isEmpty()) {
				
				RequestDispatcher dispatcher=
						request.getRequestDispatcher("managerretrievelist.jsp");
				dispatcher.forward(request,response);
			}else {
				RequestDispatcher dispatcher=
						request.getRequestDispatcher("noleaverequests.jsp");
				dispatcher.forward(request,response);
			}
		}
		}
		protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			String action=request.getParameter("action");
			if(action.contentEquals("leavebalance")) {
				int emp_id=Integer.parseInt(request.getParameter("emp_Id"));
				int leave_id = Integer.parseInt(request.getParameter("leave_id"));
				List<ManagerLeaveModel> leaveDetails = null;
				try {
					leaveDetails = managerService.checkLeaveBalances(emp_id, leave_id);
				} catch (ClassNotFoundException | SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				request.setAttribute("leaveDetails", leaveDetails);
				
				if(!leaveDetails.isEmpty()) {
					
					RequestDispatcher dispatcher=
							request.getRequestDispatcher("leavebalance.jsp");
					dispatcher.forward(request,response);
				}else {
					RequestDispatcher dispatcher=
							request.getRequestDispatcher("noleavebalance.jsp");
					dispatcher.forward(request,response);
				}

			}
			if(action.contentEquals("statusupdate")) {
				String status=request.getParameter("Status");
				int leave_id=Integer.parseInt(request.getParameter("leave_Id"));
				if(status.equals("Approve")) {
					try {
						managerService.leaveApproval(leave_id);
						RequestDispatcher dispatcher=
								request.getRequestDispatcher("leaveapproval.jsp");
						dispatcher.forward(request,response);
					} catch (ClassNotFoundException | SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}else {
					try {
						managerService.leaveRejection(leave_id);
						RequestDispatcher dispatcher=
								request.getRequestDispatcher("leaverejection.jsp");
						dispatcher.forward(request,response);
					} catch (ClassNotFoundException | SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
			}
		}
