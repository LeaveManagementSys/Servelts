package com.lms.dao;

import java.sql.SQLException;
import java.util.List;

import com.lms.entities.Leaves;



public interface LeaveDao 
{
	List<Leaves> getAllLeaveTypes() throws ClassNotFoundException, SQLException;

	int requestLeave(Leaves leave, int empId) throws ClassNotFoundException, SQLException;
}
