package com.lms.entities;

public class User 
{
	private int empId;
	private String password;
	

	public int getempId() {
		return empId;
	}

	public void setempId(int empId) {
		empId = empId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "User [empId=" + empId + ", password=" + password + "]";
	}

	

	
}
