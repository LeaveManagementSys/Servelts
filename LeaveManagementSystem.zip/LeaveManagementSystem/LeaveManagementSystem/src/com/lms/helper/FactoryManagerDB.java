package com.lms.helper;

import com.lms.dao.ManagerDAO;

import com.lms.dao.ManagerDAOImpl;
import com.lms.service.ManagerService;
import com.lms.service.ManagerServiceImpl;

public class FactoryManagerDB {

	public static ManagerDAO listLeavesManagerDAO(){
		ManagerDAO managerDAO=new ManagerDAOImpl();
		return managerDAO;
		
	}
	public static ManagerService listLeavesManagerService(){
		ManagerService employeesService=new ManagerServiceImpl();
		return employeesService;
	}
}
