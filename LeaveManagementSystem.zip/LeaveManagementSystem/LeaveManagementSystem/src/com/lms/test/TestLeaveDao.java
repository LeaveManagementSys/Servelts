package com.lms.test;

import static org.junit.Assert.*;

import java.sql.SQLException;
import java.util.List;

import org.junit.Test;

import com.lms.dao.JDBCLeaveDao;
import com.lms.dao.LeaveDao;
import com.lms.entities.Leaves;

public class TestLeaveDao 
{
	@Test
	public void testLeaveDao_positive() 
	{
		LeaveDao leaveDAO=new JDBCLeaveDao();
		
		try {
				List<Leaves> leaveList=LeaveDao.getAllLeaveTypes();
				assertEquals(true,leaveList.size()>0);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			assertTrue(false);
		}
	}

}
