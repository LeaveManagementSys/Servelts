package com.lms.test;

import static org.junit.Assert.*;

import java.sql.SQLException;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import com.lms.dao.JDBCLeaveDao;
import com.lms.dao.LeaveDao;
import com.lms.entities.LeaveBalance;
import com.lms.entities.Leaves;
import com.lms.entities.User;
import com.lms.service.LeaveServiceImpl;
import com.lms.service.UserServiceImpl;

public class TestLeaveDao 
{
	@Test
	public void testviewRequestStatus() throws ClassNotFoundException, SQLException {
		LeaveServiceImpl leaveServiceImpl=new LeaveServiceImpl();
		Leaves leave=new Leaves();
		leave.setEmpId(1005);
		
		LeaveBalance actual=leaveServiceImpl.viewLeaveBalances(leave.getEmpId());
		String expected="leaveBalance";
		assertEquals(expected,actual);
	}
	
	
}
