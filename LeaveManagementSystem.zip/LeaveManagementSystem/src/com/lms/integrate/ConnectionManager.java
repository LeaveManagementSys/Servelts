package com.lms.integrate;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionManager 
{
//private static DataSource dataSource=new DataSource();
	
	private static Connection connection=null;
	public static Connection openConnection() throws ClassNotFoundException,SQLException 
	{
		
//		Class.forName(dataSource.getDriver());
//		connection=DriverManager.getConnection(dataSource.getUrl(),dataSource.getUsername(),dataSource.getPassword());
//		return connection;
		String url = "jdbc:mysql://localhost:3306/lms";
		String username = "root";
		String pass = "ravI1@";
		Connection con = null;
		
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection(url,username,pass);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return con;
		
	}
	
	public static void closeConnection() throws SQLException{
		
		connection.close();
	}
}
