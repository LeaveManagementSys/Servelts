package com.lms.service;

import java.util.List;


import com.lms.model.InsertEmployeeModel;
import com.lms.model.RetriveEmployeeDesignationModel;
import com.lms.model.RetriveEmployeeModel;
import com.lms.model.UpdateEmpPhoneNumberModel;
import com.lms.model.UpdateEmployeeDesignationModel;
import com.lms.model.UpdateEmployeeSalaryModel;

public interface HrService {
	 List<RetriveEmployeeModel> retrieveEmployees();
	 String employeeInsert(InsertEmployeeModel insertemployeemodel);
	 String salaryupdate(UpdateEmployeeSalaryModel updateempsalarymodel);
	 String deleteEmployee(RetriveEmployeeModel retriveemployeemodel);
	 String phoneNumberUpdate(UpdateEmpPhoneNumberModel updateempphonenumbermodel);
	 String designationUpdate(UpdateEmployeeDesignationModel updateemployeedesgmodel);
     List<RetriveEmployeeDesignationModel> retrieveDesignation();
}
