package com.lms.service;

import java.sql.SQLException;

import java.util.List;
import com.lms.model.ManagerLeaveModel;
import com.lms.model.ManagerRetrieveList;

public interface ManagerService {

	public void leaveApproval(int empId) throws ClassNotFoundException, SQLException;
	public void leaveRejection(int empId) throws ClassNotFoundException, SQLException;
	//public void leaveList() throws ClassNotFoundException, SQLException;
	public List<ManagerRetrieveList> retrieveListOfLeaves();
	public List<ManagerLeaveModel> checkLeaveBalances(int empId, int leave_id)throws ClassNotFoundException, SQLException;
}
