package com.lms.helper;


import com.lms.dao.EmployeeDao;
import com.lms.dao.HrDao;
import com.lms.dao.HrDaoImpl;
import com.lms.dao.JDBCEmployeeDao;
import com.lms.service.HrService;
import com.lms.service.HrServiceImpl;

public class FactoryHr {

	public static HrService createHrService()
	{
		HrService hrservice=new HrServiceImpl();
		return hrservice;	
	}
	
	public static HrDao createEmployeeDao()
	{
		HrDao	hrdao=new HrDaoImpl();
		return hrdao;
	}
}
