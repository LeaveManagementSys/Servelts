# LeaveManagementSystem
Design a platform to send/add, change/manage, delete and approve/reject leave requests
