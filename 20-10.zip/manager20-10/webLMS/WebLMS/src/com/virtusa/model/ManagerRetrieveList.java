package com.virtusa.model;

public class ManagerRetrieveList {

	private int  leave_Id;
	private int emp_Id;
	private String leave_Type;
	private String from_Date;
	private String to_Date;
	private String designation;
	private String status;
	private String leave_desc;
	public int getLeave_Id() {
		return leave_Id;
	}
	public void setLeave_Id(int leave_Id) {
		this.leave_Id = leave_Id;
	}
	public int getEmp_Id() {
		return emp_Id;
	}
	public void setEmp_Id(int emp_Id) {
		this.emp_Id = emp_Id;
	}
	public String getLeave_Type() {
		return leave_Type;
	}
	public void setLeave_Type(String leave_Type) {
		this.leave_Type = leave_Type;
	}
	public String getFrom_Date() {
		return from_Date;
	}
	public void setFrom_Date(String from_Date) {
		this.from_Date = from_Date;
	}
	public String getTo_Date() {
		return to_Date;
	}
	public void setTo_Date(String to_Date) {
		this.to_Date = to_Date;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getLeave_desc() {
		return leave_desc;
	}
	public void setLeave_desc(String leave_desc) {
		this.leave_desc = leave_desc;
	}
	
	
	
}
